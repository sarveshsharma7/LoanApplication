package com.example.chatbot;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.*;

public class MainActivity extends AppCompatActivity {
    private static final String API_URL = "https://api.openai.com/v1/chat/completions";
    private static final String API_KEY = "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";
    private static final OkHttpClient client = new OkHttpClient();

    private EditText userInput;
    private TextView chatDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userInput = findViewById(R.id.user_input);
        chatDisplay = findViewById(R.id.chat_display);
        Button sendButton = findViewById(R.id.send_button);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = userInput.getText().toString().trim();
                if (!message.isEmpty()) {
                    try {
                        sendMessageToChatbot(message);
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                    userInput.getText().clear();
                }
            }
        });
    }

    private void sendMessageToChatbot(String message) throws JSONException {
        MediaType mediaType = MediaType.parse("application/json");
        JSONObject requestBody = new JSONObject();
        JSONArray messages = new JSONArray();

        JSONObject messageObject = new JSONObject();
        messageObject.put("role", "system");
        messageObject.put("content", "You are a helpful assistant.");
        messages.put(messageObject);

        messageObject = new JSONObject();
        messageObject.put("role", "user");
        messageObject.put("content", message);
        messages.put(messageObject);

        requestBody.put("messages", messages);
        requestBody.put("max_tokens", 50); // Adjust max tokens as needed

        Request request = new Request.Builder()
                .url(API_URL)
                .addHeader("Authorization", "Bearer " + API_KEY)
                .post(RequestBody.create(mediaType, requestBody.toString()))
                .build();

        new ChatbotAPIRequest().execute(request);
    }

    private class ChatbotAPIRequest extends AsyncTask<Request, Void, String> {
        @Override
        protected String doInBackground(Request... requests) {
            Request request = requests[0];
            Response response;
            try {
                response = client.newCall(request).execute();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            if (response.isSuccessful()) {
                String responseBody = null;
                try {
                    responseBody = response.body().string();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                JSONObject jsonResponse = null;
                try {
                    jsonResponse = new JSONObject(responseBody);
                } catch (JSONException ex) {
                    throw new RuntimeException(ex);
                }
                JSONArray choices = null;
                try {
                    choices = jsonResponse.getJSONArray("choices");
                } catch (JSONException ex) {
                    throw new RuntimeException(ex);
                }

                if (choices.length() > 0) {
                    JSONObject chatbotResponse = null;
                    try {
                        chatbotResponse = choices.getJSONObject(0);
                    } catch (JSONException ex) {
                        throw new RuntimeException(ex);
                    }
                    try {
                        return chatbotResponse.getString("text");
                    } catch (JSONException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            } else {
                return "Failed to get a response from the API.";
            }

            return null;
        }

        @Override
        protected void onPostExecute(String response) {
            if (response != null) {
                appendMessageToChat(response, true);
            }
        }
    }

    private void appendMessageToChat(String message, boolean isChatbot) {
        String prefix = isChatbot ? "Chatbot: " : "You: ";
        chatDisplay.append(prefix + message + "\n");
    }
}
